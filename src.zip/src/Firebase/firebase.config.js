const firebaseConfig = {
    apiKey: "AIzaSyCakICqHbUnUijXebRAxZSzqm3pmw7wXi0",
    authDomain: "curier-service.firebaseapp.com",
    projectId: "curier-service",
    storageBucket: "curier-service.appspot.com",
    messagingSenderId: "385957461255",
    appId: "1:385957461255:web:8a5897457e8193535d19a2"
};

export default firebaseConfig;